package game;

import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import org.jbox2d.common.Vec2;

import java.awt.*;
import java.awt.print.Book;

public class Level2  extends GameLevel{

    public Level2(Game game){
        //the base class will create the student, professor
        //and the ProfessorEncounter
        super(game);

        //we still need to set the positions of the student
        //and professor
        getThief().setPosition(new Vec2(-15, -10));
        getArabKnight().setPosition(new Vec2(-8,0));

        //we're setting up BooksPickup here though we could
        //also add it to the GameLevel class
        getThief().addCollisionListener(new CoinsPickup(getThief()));

        //  the ground
        Shape shape = new BoxShape(20, 0.5f);
        StaticBody ground = new StaticBody(this, shape);
        ground.setPosition(new Vec2(0f, -11.5f));
        ground.setFillColor(Color.white);

        // Walls
        Shape wallShape = new BoxShape(0.5f, 15f);
        StaticBody wall1 = new StaticBody(this, wallShape);
        wall1.setPosition(new Vec2(-20.5f, 3));
        wall1.setFillColor(Color.white);
        StaticBody wall2 = new StaticBody(this, wallShape);
        wall2.setPosition(new Vec2(20.5f, 3));
        wall2.setFillColor(Color.white);

        Shape platform3Shape = new BoxShape(15, 0.5f);
        StaticBody platform3 = new StaticBody(this, platform3Shape);
        platform3.setPosition(new Vec2(-6, -1f));
        platform3.setFillColor(Color.white);


        Shape step1Shape = new BoxShape(3, 0.25f);
        StaticBody step1 = new StaticBody(this, step1Shape);
        step1.setPosition(new Vec2(-8, -9.5f));
        step1.setFillColor(Color.white);

        Shape step2Shape = new BoxShape(3, 0.25f);
        StaticBody step2 = new StaticBody(this, step2Shape);
        step2.setPosition(new Vec2(0, -7.5f));
        step2.setFillColor(Color.white);

        Shape step3Shape = new BoxShape(3, 0.25f);
        StaticBody step3 = new StaticBody(this, step3Shape);
        step3.setPosition(new Vec2(8, -5.5f));
        step3.setFillColor(Color.white);

        Shape step4Shape = new BoxShape(5, 0.25f);
        StaticBody step4 = new StaticBody(this, step4Shape);
        step4.setPosition(new Vec2(16, -3.5f));
        step4.setFillColor(Color.white);

        Shape step5Shape = new BoxShape(5, 0.25f);
        StaticBody step5= new StaticBody(this, step5Shape);
        step5.setPosition(new Vec2(16, 2));
        step5.setFillColor(Color.white);

        // escape door
        EscapeDoor escapeDoor = new EscapeDoor(this);
        escapeDoor.setPosition(new Vec2(18, 2.5f));

        // Spawning coins


        for (int i = 0; i < 4; i++) {
            coins Coins = new coins(this);
            Coins.setPosition(new Vec2(i*1+17, -3));
        }

        for (int i = 0; i < 4; i++) {
            coins Coins = new coins(this);
            Coins.setPosition(new Vec2(i*1-18, 2));
        }


    }
    @Override
    public boolean isComplete() {
        if (getThief().getCoinsCount() == 8)
            return true;
        else
            return false;
    }
}
