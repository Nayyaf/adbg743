package game;

import city.cs.engine.DebugViewer;
import city.cs.engine.SoundClip;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JFrame;
import java.io.IOException;

/**
 * A world with some bodies.
 */
public class Game {

    /**
     * The World in which the bodies move and interact.
     */
    private GameLevel level;

    /**
     * A graphical display of the world (a specialised JPanel).
     */
    private GameView view;

    private ThiefController controller;

    private SoundClip gameMusic;


    /**
     * Initialise a new Game.
     */
    public Game() {

        try {
            gameMusic = new SoundClip("data/gametheme.wav");   // Open an audio input stream
            gameMusic.loop();  // Set it to continous playback (looping)
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println(e);
        }

        // initialise level

        level = new Level1(this);

        // make a view
        view = new GameView(level, 752, 360);
        view.setZoom(10);

        // uncomment this to draw a 1-metre grid over the view
        // view.setGridResolution(1);

        controller = new ThiefController(level.getThief());
        view.addKeyListener(controller);

        view.addMouseListener(new GiveFocus(view));

        level.addStepListener(new Tracker(view, level.getThief()));


        // add the view to a frame (Java top level window)
        final JFrame frame = new JFrame("Thief");
        frame.add(view);
        // enable the frame to quit the application
        // when the x button is pressed
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationByPlatform(true);
        // don't let the frame be resized
        frame.setResizable(false);
        // size the frame to fit the world view
        frame.pack();
        // finally, make the frame visible
        frame.setVisible(true);



        // uncomment this to make a debugging view
        // JFrame debugView = new DebugViewer(world, 500, 500);

        // start our game world simulation!
        level.start();
    }

    public void goToNextLevel() {

        if (level instanceof Level1) {
            //stop the current level
            level.stop();
            //create the new (appropriate) level
            //level now refers to new level
            level = new Level2(this);
            //change the view to look into new level
            level.addStepListener(new Tracker(view, level.getThief()));
            view.setZoom(10);
            view.setWorld(level);
            //change the controller to control the
            //Thief in the new world
            controller.updateThief(level.getThief());
            //start the simulation in the new level
            level.start();
        } else if (level instanceof Level2) {
            //stop the current level
            level.stop();
            //create the new (appropriate) level
            //level now refers to new level
            level = new Level3(this);
            //change the view to look into new level
            level.addStepListener(new Tracker(view, level.getThief()));
            view.setZoom(10);
            view.setWorld(level);
            //change the controller to control the
            //Thief in the new world
            controller.updateThief(level.getThief());
            //start the simulation in the new level
            level.start();
        }
        else if (level instanceof Level3) {
            System.out.println("Well done! Game complete.");
            System.exit(0);

        }
    }



        /** Run the game. */
        public static void main(String[] args) {

            new Game();
    }
}