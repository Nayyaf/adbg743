package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;

public class CoinsPickup  implements CollisionListener {
    private Thief thief;

    public CoinsPickup(Thief t) {
        this.thief = t;
    }


    @Override
    public void collide(CollisionEvent e) {
        if (e.getOtherBody() instanceof coins) {
            thief.incrementCoins();
            e.getOtherBody().destroy();
        }
    }
}






