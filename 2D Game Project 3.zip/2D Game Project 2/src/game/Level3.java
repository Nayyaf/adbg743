package game;

import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import org.jbox2d.common.Vec2;

import java.awt.*;

public class Level3  extends GameLevel{

    public Level3(Game game){
        //the base class will create the student, professor
        //and the ProfessorEncounter
        super(game);

        //we still need to set the positions of the student
        //and professor
        getThief().setPosition(new Vec2(-15, -10));
        getArabKnight().setPosition(new Vec2(-8,0));

        //we're setting up BooksPickup here though we could
        //also add it to the GameLevel class
        getThief().addCollisionListener(new CoinsPickup(getThief()));

        //  the ground
        Shape shape = new BoxShape(20, 0.5f);
        StaticBody ground = new StaticBody(this, shape);
        ground.setPosition(new Vec2(0f, -11.5f));
        ground.setFillColor(Color.white);

        // Walls
        Shape wallShape = new BoxShape(0.5f, 15f);
        StaticBody wall1 = new StaticBody(this, wallShape);
        wall1.setPosition(new Vec2(-20.5f, 3));
        wall1.setFillColor(Color.white);
        StaticBody wall2 = new StaticBody(this, wallShape);
        wall2.setPosition(new Vec2(20.5f, 3));
        wall2.setFillColor(Color.white);

        Shape platform1Shape = new BoxShape(13, 0.5f);
        StaticBody platform1 = new StaticBody(this, platform1Shape);
        platform1.setPosition(new Vec2(-12, 4));
        platform1.setFillColor(Color.white);
        platform1.setAngleDegrees(-45);

        Shape platform2Shape = new BoxShape(13, 0.5f);
        StaticBody platform2 = new StaticBody(this, platform2Shape);
        platform2.setPosition(new Vec2(12, 4));
        platform2.setFillColor(Color.white);
        platform2.setAngleDegrees(45);

        Shape step5Shape = new BoxShape(3, 0.25f);
        StaticBody step5= new StaticBody(this, step5Shape);
        step5.setPosition(new Vec2(0, -8));
        step5.setFillColor(Color.white);

        Shape step6Shape = new BoxShape(3, 0.25f);
        StaticBody step6= new StaticBody(this, step6Shape);
        step6.setPosition(new Vec2(0, 4.5f));
        step6.setFillColor(Color.white);

        // escape door
        EscapeDoor escapeDoor = new EscapeDoor(this);
        escapeDoor.setPosition(new Vec2(0, 5f));

        // Spawning coins


        for (int i = 0; i < 4; i++) {
            coins Coins = new coins(this);
            Coins.setPosition(new Vec2(i*1+17, -3));
        }

    }
    @Override
    public boolean isComplete() {
        if (getThief().getCoinsCount() == 4)
            return true;
        else
            return false;
    }
}

