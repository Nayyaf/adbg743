package game;

import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import org.jbox2d.common.Vec2;

import java.awt.*;

public class Level1  extends GameLevel{

    private Thief thief;
    private ArabKnight arabKnight;
    public Level1(Game game){
        //the base class will create the student, professor
        //and the ProfessorEncounter
        super(game);

        //we still need to set the positions of the student
        //and professor
        getThief().setPosition(new Vec2(-15, -10));
        getArabKnight().setPosition(new Vec2(8,-10));

        //we're setting up BooksPickup here though we could
        //also add it to the GameLevel class
        getThief().addCollisionListener(new CoinsPickup(getThief()));

         // make the ground
        Shape shape = new BoxShape(20, 0.5f);
        StaticBody ground = new StaticBody(this, shape);
        ground.setPosition(new Vec2(0f, -11.5f));
        ground.setFillColor(Color.white);

        // make First Floor
        Shape firstfloorshape = new BoxShape(15, 0.5f);
        StaticBody floor= new StaticBody(this, firstfloorshape);
        floor.setPosition(new Vec2(-5f, -3f));
        floor.setFillColor(Color.white);

        //  platform 1
        Shape platform1Shape = new BoxShape(4, 0.5f);
        StaticBody platform1 = new StaticBody(this, platform1Shape);
        platform1.setPosition(new Vec2(-9, 4));
        platform1.setFillColor(Color.white);


        //  platform 2
        Shape platform2Shape = new BoxShape(8, 0.5f);
        StaticBody platform2 = new StaticBody(this, platform2Shape);
        platform2.setPosition(new Vec2(12, 2.5f));
        platform2.setFillColor(Color.white);

        // Walls
        Shape wallShape = new BoxShape(0.5f, 15f);
        StaticBody wall1 = new StaticBody(this, wallShape);
        wall1.setPosition(new Vec2(-20.5f, 3));
        wall1.setFillColor(Color.white);
        StaticBody wall2 = new StaticBody(this, wallShape);
        wall2.setPosition(new Vec2(20.5f, 3));
        wall2.setFillColor(Color.white);

        Shape platform3Shape = new BoxShape(6, 0.5f);
        StaticBody platform3 = new StaticBody(this, platform3Shape);
        platform3.setPosition(new Vec2(10, -8f));
        platform3.setFillColor(Color.white);

        Shape platform5Shape = new BoxShape(2, 0.25f);
        StaticBody platform5 = new StaticBody(this, platform5Shape);
        platform5.setPosition(new Vec2(18, -4));
        platform5.setFillColor(Color.white);

        Shape platform6Shape = new BoxShape(3, 0.25f);
        StaticBody platform6 = new StaticBody(this, platform6Shape);
        platform6.setPosition(new Vec2(-17, 0.5f));
        platform6.setFillColor(Color.white);

        Shape platform7Shape = new BoxShape(15, 0.5f);
        StaticBody platform7 = new StaticBody(this, platform7Shape);
        platform7.setPosition(new Vec2(-2, 12));
        platform7.setFillColor(Color.white);
        platform7.setAngleDegrees(-18);

        Shape platform8Shape = new BoxShape(1, 0.25f);
        StaticBody platform8 = new StaticBody(this, platform8Shape);
        platform8.setPosition(new Vec2(14, 6));
        platform8.setFillColor(Color.white);

        Shape escapeShape = new BoxShape(2, 0.25f);
        StaticBody escape = new StaticBody(this, escapeShape);
        escape.setPosition(new Vec2(-18, 17));
        escape.setFillColor(Color.white);

        // enemies
        arabKnight = new ArabKnight(this);
        arabKnight.setPosition(new Vec2(8, -10));

        arabKnight = new ArabKnight(this);
        arabKnight.setPosition(new Vec2(8, 4));

        arabKnight = new ArabKnight(this);
        arabKnight.setPosition(new Vec2(-8, 5));

        arabKnight = new ArabKnight(this);
        arabKnight.setPosition(new Vec2(-13, -2));

        // escape door
        EscapeDoor escapeDoor = new EscapeDoor(this);
        escapeDoor.setPosition(new Vec2(-18, 18));

        // Spawning coins
        for (int i = 0; i < 8; i++) {
            coins Coins = new coins(this);
            Coins.setPosition(new Vec2(i*4-10, -11));
        }


        for (int i = 0; i < 3; i++) {
            coins Coins = new coins(this);
            Coins.setPosition(new Vec2(i*1+17, -3));
        }

        for (int i = 0; i < 4; i++) {
            coins Coins = new coins(this);
            Coins.setPosition(new Vec2(i*1-18, 2));
        }

        for (int i = 0; i < 3; i++) {
            coins Coins = new coins(this);
            Coins.setPosition(new Vec2(i*1-12, 5));
        }

        for (int i = 0; i < 2; i++) {
            coins Coins = new coins(this);
            Coins.setPosition(new Vec2(i-2-4, 5));
        }

    }
    @Override
    public boolean isComplete() {
        if (getThief().getCoinsCount() == 20)
            return true;
        else
            return false;
    }

}
