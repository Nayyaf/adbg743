/*package game;

import city.cs.engine.UserView;
import city.cs.engine.World;
import org.jbox2d.common.Vec2;

import javax.swing.ImageIcon;
import javax.swing.Icon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.*;


public class AnimatedGif extends JFrame {

    public AnimatedGif(){
        Icon imgIcon = new ImageIcon(this.getClass().getResource("House.gif"));
        JLabel label = new JLabel(imgIcon);
        label.setSize(100,100);
        this.getContentPane().add(label);
        setSize(500,500);
        setVisible(true);
    }
    public static void main(String[] args){
        new AnimatedGif();
    }

    public Vec2 viewToWorld(viewtoAnimatedGif mousePoint) {
    }
}


 */

