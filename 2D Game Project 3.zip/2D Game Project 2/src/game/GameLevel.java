package game;

import city.cs.engine.World;

public abstract class GameLevel extends World {
    private Thief thief;
    private ArabKnight arabKnight;

    public GameLevel(Game game){
        //all levels have a thief, a arabKnight
        //and the thief needs to reach the arabKnight
        //to complete the game (hence a ArabKnightEncounter)
        thief = new Thief(this);
        arabKnight = new ArabKnight(this);
        Escape encounter = new Escape(this, game);
        thief.addCollisionListener(encounter);
        Enemycollision deaths = new Enemycollision(thief);
        thief.addCollisionListener(new Enemycollision(thief));

    }


    public Thief getThief(){
        return thief;
    }
    public ArabKnight getArabKnight(){
        return arabKnight;
    }
    public abstract boolean isComplete();
}
