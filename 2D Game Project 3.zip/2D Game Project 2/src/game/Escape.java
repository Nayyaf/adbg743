package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
import org.jbox2d.common.Vec2;

public class Escape implements CollisionListener {
    private Thief thief;
    private GameLevel level;
    private Game game;

    public Escape(GameLevel level, Game game) {
        this.level = level;
        this.game = game;

    }

    @Override
    public void collide(CollisionEvent e) {
        //if student collided with professor and the
        //conditions for completing the level are fulfilled
        //goToNextLevel
        if (e.getOtherBody() instanceof EscapeDoor
                && level.isComplete()) {
            game.goToNextLevel();

        }
    }
}