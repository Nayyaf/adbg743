package game;

import city.cs.engine.*;

public class Thief extends Walker {
    private static final Shape ThiefShape = new PolygonShape(
            -0.22f, 1.0f, -0.79f, 0.51f, -0.6f, -0.85f, -0.36f, -1.12f, 0.25f, -1.13f, 0.71f, -0.16f, 0.3f, 0.81f);

    private static final BodyImage image =
            new BodyImage("data/ThiefR.png", 3.0f);
    private static final BodyImage imageL =
            new BodyImage("data/ThiefL.png", 3.0f);

    private int CoinsCount;
    private int livesCount;

    public Thief(World world) {
        super(world, ThiefShape);
        addImage(image);

        CoinsCount = 0;
        livesCount = 3;
    }

    public BodyImage getImageLeft() {
        return imageL;
    }

    public BodyImage getImageRight() {
        return image;
    }


    public void incrementCoins() {
        CoinsCount++;
        System.out.println("Steal the coins: " +
                "coins stolen = " + CoinsCount);
    }


    public int getCoinsCount() {
        return CoinsCount;
    }


    public int getLivesCount() {
        return livesCount;
    }

    public void decrementlivesCount() {
        livesCount--;

        if (livesCount == 0) {
            System.out.println("Game over you're out of lives!");
        } else if (livesCount < 0) {
            System.out.println("Khalas stop trying you died!");
        } else {
            System.out.println("Watch out for the guards: " +
                    "lives left = " + livesCount);
        }

    }
}