package game;

import city.cs.engine.*;

public class EscapeDoor extends Walker {

    private static final Shape EscapeDoorShape = new PolygonShape(
            -0.62f,-1.11f, 0.32f,-1.11f, 0.86f,0.66f, -0.06f,0.85f, -0.54f,0.7f, -0.72f,0.17f, -0.79f,-0.38f);
    private static final BodyImage image =
            new BodyImage("data/escape.png", 3.0f);


    public EscapeDoor(World world) {
        super(world, EscapeDoorShape);
        addImage(image);

    }
}