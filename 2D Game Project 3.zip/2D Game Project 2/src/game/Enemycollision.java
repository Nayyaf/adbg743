package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
import org.jbox2d.common.Vec2;

public class Enemycollision implements CollisionListener {
    private Thief thief;

    public Enemycollision(Thief t) {
        this.thief = t;
    }


    @Override
    public void collide(CollisionEvent e) {
        if (e.getOtherBody() instanceof ArabKnight) {
            thief.decrementlivesCount();
            thief.setPosition(new Vec2(-15, -10));
        }
    }
}
