package game;

import city.cs.engine.*;

public class coins extends DynamicBody {

    private static final Shape coinShape = new CircleShape(0.5f);

    private static final BodyImage image =
            new BodyImage("data/coins.png", 0.5f);

    public coins(World world) {
        super(world,coinShape);
        addImage(image);

    }
}
