package game;

import org.jbox2d.common.Vec2;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class ThiefController implements KeyListener {

    private static final float WALKING_SPEED = 4;

    private Thief thief;

    public ThiefController(Thief t) {
        thief = t;
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        // other key commands omitted
        if (code == KeyEvent.VK_A || code == KeyEvent.VK_LEFT) {
            thief.startWalking(-WALKING_SPEED);
            thief.removeAllImages();
            thief.addImage(thief.getImageLeft());

        }
        else if (code == KeyEvent.VK_D || code == KeyEvent.VK_RIGHT) {
            thief.startWalking(WALKING_SPEED);
            thief.removeAllImages();
            thief.addImage(thief.getImageRight());

        } else if (code == KeyEvent.VK_W || code == KeyEvent.VK_UP) {
            thief.setLinearVelocity(new Vec2(0, 9));


        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_A || code == KeyEvent.VK_LEFT) {
            thief.stopWalking();
        } else if (code == KeyEvent.VK_D || code == KeyEvent.VK_RIGHT) {
            thief.stopWalking();
        }
    }

    public void updateThief(Thief thief){

        this.thief = thief;
    }
}
